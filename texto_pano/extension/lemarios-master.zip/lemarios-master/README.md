
# Lemarios y listas de palabras del español 

Proyecto para la confección y publicación abierta de listas de palabras del
español. 

Encontrarán referencias a otras listas de palabras en
http://olea.org/proyectos/lemarios/

El objetivo inicial es recopilar material necesario para completar el
corrector ortográfico libre de «Recursos Lingüísticos Abiertos»
(https://forja.rediris.es/projects/rla-es/), usado en todas las
distribuciones Linux, LibreOffice/OpenOffice, Firefox, etc. Asímismo quedan
a la disposición de desarrolladores y lingüístas sin restricción ninguna.

Si dispone de material que considere relevante considere contribuirlo.

Los ficheros están codificados en Unicode UTF-8.

__Todos__ los materiales aquí publicados están y serán cedidos al dominio
público en loor de la máxima reutilización y el mejor desarrollo del
español en la tecnología.

Contacte con nosotros a través de https://github.com/olea/lemarios/issues

